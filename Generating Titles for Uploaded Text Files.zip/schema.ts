import { int, mysqlEnum, mysqlTable, text, timestamp, varchar } from "drizzle-orm/mysql-core";

/**
 * Core user table backing auth flow.
 * Extend this file with additional tables as your product grows.
 * Columns use camelCase to match both database fields and generated types.
 */
export const users = mysqlTable("users", {
  /**
   * Surrogate primary key. Auto-incremented numeric value managed by the database.
   * Use this for relations between tables.
   */
  id: int("id").autoincrement().primaryKey(),
  /** Manus OAuth identifier (openId) returned from the OAuth callback. Unique per user. */
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

// Fraud Detection System Tables

export const transactions = mysqlTable("transactions", {
  id: int("id").autoincrement().primaryKey(),
  transactionId: varchar("transactionId", { length: 64 }).notNull().unique(),
  customerId: varchar("customerId", { length: 64 }).notNull(),
  amount: int("amount").notNull(), // in cents
  location: varchar("location", { length: 255 }).notNull(),
  merchant: varchar("merchant", { length: 255 }).notNull(),
  paymentMode: varchar("paymentMode", { length: 64 }).notNull(),
  isFraud: int("isFraud").notNull().default(0), // 0 = normal, 1 = fraud
  fraudScore: int("fraudScore").notNull().default(0), // 0-100
  fraudProbability: int("fraudProbability").notNull().default(0), // 0-100
  modelUsed: varchar("modelUsed", { length: 64 }).notNull().default('xgboost'),
  // Risk factors for fraud score breakdown
  frequency: int("frequency").notNull().default(1),
  distance: int("distance").notNull().default(0), // in km
  deviceRisk: int("deviceRisk").notNull().default(10), // 0-100
  locationRisk: int("locationRisk").notNull().default(10), // 0-100
  merchantRisk: int("merchantRisk").notNull().default(10), // 0-100
  hour: int("hour").notNull().default(12), // 0-23
  dayOfWeek: int("dayOfWeek").notNull().default(3), // 0-6
  // Score factor contributions
  amountContribution: int("amountContribution").notNull().default(0),
  frequencyContribution: int("frequencyContribution").notNull().default(0),
  locationContribution: int("locationContribution").notNull().default(0),
  deviceContribution: int("deviceContribution").notNull().default(0),
  merchantContribution: int("merchantContribution").notNull().default(0),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export const fraudAlerts = mysqlTable("fraudAlerts", {
  id: int("id").autoincrement().primaryKey(),
  transactionId: varchar("transactionId", { length: 64 }).notNull(),
  customerId: varchar("customerId", { length: 64 }).notNull(),
  alertType: varchar("alertType", { length: 64 }).notNull(), // 'high_amount', 'unusual_location', 'high_frequency'
  severity: mysqlEnum("severity", ["low", "medium", "high", "critical"]).notNull(),
  message: text("message").notNull(),
  isResolved: int("isResolved").notNull().default(0),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  resolvedAt: timestamp("resolvedAt"),
});

export const fraudStats = mysqlTable("fraudStats", {
  id: int("id").autoincrement().primaryKey(),
  date: varchar("date", { length: 10 }).notNull(), // YYYY-MM-DD
  hour: int("hour").notNull(), // 0-23
  totalTransactions: int("totalTransactions").notNull().default(0),
  fraudCount: int("fraudCount").notNull().default(0),
  totalAmount: int("totalAmount").notNull().default(0), // in cents
  fraudAmount: int("fraudAmount").notNull().default(0), // in cents
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type Transaction = typeof transactions.$inferSelect;
export type InsertTransaction = typeof transactions.$inferInsert;
export type FraudAlert = typeof fraudAlerts.$inferSelect;
export type InsertFraudAlert = typeof fraudAlerts.$inferInsert;
export type FraudStat = typeof fraudStats.$inferSelect;
export type InsertFraudStat = typeof fraudStats.$inferInsert;
