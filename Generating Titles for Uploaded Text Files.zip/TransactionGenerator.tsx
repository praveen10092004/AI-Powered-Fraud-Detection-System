import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Slider } from "@/components/ui/slider";
import { AlertCircle, Send, Zap } from "lucide-react";
import { trpc } from "@/lib/trpc";
import { toast } from "sonner";

const MERCHANTS = [
  "Electronics Store",
  "Gas Station",
  "Restaurant",
  "Online Shopping",
  "Hotel",
  "ATM",
  "Pharmacy",
  "Grocery Store",
];

const LOCATIONS = [
  "New York",
  "Los Angeles",
  "Chicago",
  "Houston",
  "Phoenix",
  "Philadelphia",
  "San Antonio",
  "San Diego",
];

const PAYMENT_MODES = ["Credit Card", "Debit Card", "Mobile Wallet", "Bank Transfer"];

export default function TransactionGenerator() {
  const [formData, setFormData] = useState({
    amount: 100,
    customerId: "CUST-" + Math.random().toString(36).substr(2, 9).toUpperCase(),
    location: LOCATIONS[0],
    merchant: MERCHANTS[0],
    paymentMode: PAYMENT_MODES[0],
    frequency: 1,
    distance: 0,
    card_age: 1000,
    device_risk: 0.1,
    location_risk: 0.1,
    hour: new Date().getHours(),
    day_of_week: new Date().getDay(),
    merchant_risk: 0.1,
    time: Math.floor(Math.random() * 86400),
  });

  const [isGenerating, setIsGenerating] = useState(false);
  const [generatedCount, setGeneratedCount] = useState(0);

  const analyzeTransaction = trpc.fraud.analyzeTransaction.useMutation();

  const handleInputChange = (field: string, value: any) => {
    setFormData((prev) => ({
      ...prev,
      [field]: value,
    }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const result = await analyzeTransaction.mutateAsync({
        amount: formData.amount,
        customerId: formData.customerId,
        location: formData.location,
        merchant: formData.merchant,
        paymentMode: formData.paymentMode,
        frequency: formData.frequency,
        distance: formData.distance,
        card_age: formData.card_age,
        device_risk: formData.device_risk,
        location_risk: formData.location_risk,
        hour: formData.hour,
        day_of_week: formData.day_of_week,
        merchant_risk: formData.merchant_risk,
        time: formData.time,
      });

      toast.success(
        result.isFraud
          ? `Fraud Detected! Score: ${result.fraudScore}%`
          : `Transaction Normal. Score: ${result.fraudScore}%`
      );

      setGeneratedCount((prev) => prev + 1);
    } catch (error) {
      toast.error("Failed to analyze transaction");
    }
  };

  const generateBulkTransactions = async () => {
    setIsGenerating(true);
    try {
      for (let i = 0; i < 10; i++) {
        const randomAmount = Math.random() * 10000;
        const randomLocation = LOCATIONS[Math.floor(Math.random() * LOCATIONS.length)];
        const randomMerchant = MERCHANTS[Math.floor(Math.random() * MERCHANTS.length)];
        const randomPaymentMode = PAYMENT_MODES[Math.floor(Math.random() * PAYMENT_MODES.length)];
        const randomFrequency = Math.floor(Math.random() * 10) + 1;
        const randomDistance = Math.random() * 5000;
        const randomDeviceRisk = Math.random();
        const randomLocationRisk = Math.random();
        const randomMerchantRisk = Math.random();

        await analyzeTransaction.mutateAsync({
          amount: randomAmount,
          customerId: formData.customerId,
          location: randomLocation,
          merchant: randomMerchant,
          paymentMode: randomPaymentMode,
          frequency: randomFrequency,
          distance: randomDistance,
          card_age: formData.card_age,
          device_risk: randomDeviceRisk,
          location_risk: randomLocationRisk,
          hour: formData.hour,
          day_of_week: formData.day_of_week,
          merchant_risk: randomMerchantRisk,
          time: Math.floor(Math.random() * 86400),
        });

        // Add delay between requests
        await new Promise((resolve) => setTimeout(resolve, 500));
      }

      toast.success("10 transactions generated successfully!");
      setGeneratedCount((prev) => prev + 10);
    } catch (error) {
      toast.error("Error generating bulk transactions");
    } finally {
      setIsGenerating(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 p-6">
      <div className="max-w-4xl mx-auto">
        <div className="mb-8">
          <h1 className="text-4xl font-bold text-slate-900 mb-2">Transaction Generator</h1>
          <p className="text-slate-600">Create test transactions to analyze fraud detection</p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Form */}
          <div className="lg:col-span-2">
            <Card className="bg-white shadow-sm border-0">
              <CardHeader>
                <CardTitle>Create Transaction</CardTitle>
                <CardDescription>Fill in transaction details for fraud analysis</CardDescription>
              </CardHeader>
              <CardContent>
                <form onSubmit={handleSubmit} className="space-y-6">
                  {/* Amount */}
                  <div>
                    <Label className="text-slate-700 font-semibold">Amount ($)</Label>
                    <div className="flex gap-4 items-center mt-2">
                      <Slider
                        value={[formData.amount]}
                        onValueChange={(value) => handleInputChange("amount", value[0])}
                        min={10}
                        max={50000}
                        step={100}
                        className="flex-1"
                      />
                      <Input
                        type="number"
                        value={formData.amount}
                        onChange={(e) => handleInputChange("amount", parseFloat(e.target.value))}
                        className="w-24"
                      />
                    </div>
                  </div>

                  {/* Customer ID */}
                  <div>
                    <Label className="text-slate-700 font-semibold">Customer ID</Label>
                    <Input
                      value={formData.customerId}
                      onChange={(e) => handleInputChange("customerId", e.target.value)}
                      className="mt-2"
                    />
                  </div>

                  {/* Location */}
                  <div>
                    <Label className="text-slate-700 font-semibold">Location</Label>
                    <Select value={formData.location} onValueChange={(value) => handleInputChange("location", value)}>
                      <SelectTrigger className="mt-2">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {LOCATIONS.map((loc) => (
                          <SelectItem key={loc} value={loc}>
                            {loc}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  {/* Merchant */}
                  <div>
                    <Label className="text-slate-700 font-semibold">Merchant</Label>
                    <Select value={formData.merchant} onValueChange={(value) => handleInputChange("merchant", value)}>
                      <SelectTrigger className="mt-2">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {MERCHANTS.map((merchant) => (
                          <SelectItem key={merchant} value={merchant}>
                            {merchant}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  {/* Payment Mode */}
                  <div>
                    <Label className="text-slate-700 font-semibold">Payment Mode</Label>
                    <Select
                      value={formData.paymentMode}
                      onValueChange={(value) => handleInputChange("paymentMode", value)}
                    >
                      <SelectTrigger className="mt-2">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {PAYMENT_MODES.map((mode) => (
                          <SelectItem key={mode} value={mode}>
                            {mode}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  {/* Risk Factors */}
                  <div className="space-y-4 p-4 bg-slate-50 rounded-lg border border-slate-200">
                    <h3 className="font-semibold text-slate-700">Risk Factors</h3>

                    <div>
                      <Label className="text-sm">Transaction Frequency: {formData.frequency}</Label>
                      <Slider
                        value={[formData.frequency]}
                        onValueChange={(value) => handleInputChange("frequency", value[0])}
                        min={1}
                        max={20}
                        step={1}
                        className="mt-2"
                      />
                    </div>

                    <div>
                      <Label className="text-sm">Distance (km): {formData.distance.toFixed(0)}</Label>
                      <Slider
                        value={[formData.distance]}
                        onValueChange={(value) => handleInputChange("distance", value[0])}
                        min={0}
                        max={5000}
                        step={100}
                        className="mt-2"
                      />
                    </div>

                    <div>
                      <Label className="text-sm">Device Risk: {formData.device_risk.toFixed(2)}</Label>
                      <Slider
                        value={[formData.device_risk]}
                        onValueChange={(value) => handleInputChange("device_risk", value[0])}
                        min={0}
                        max={1}
                        step={0.1}
                        className="mt-2"
                      />
                    </div>

                    <div>
                      <Label className="text-sm">Location Risk: {formData.location_risk.toFixed(2)}</Label>
                      <Slider
                        value={[formData.location_risk]}
                        onValueChange={(value) => handleInputChange("location_risk", value[0])}
                        min={0}
                        max={1}
                        step={0.1}
                        className="mt-2"
                      />
                    </div>

                    <div>
                      <Label className="text-sm">Merchant Risk: {formData.merchant_risk.toFixed(2)}</Label>
                      <Slider
                        value={[formData.merchant_risk]}
                        onValueChange={(value) => handleInputChange("merchant_risk", value[0])}
                        min={0}
                        max={1}
                        step={0.1}
                        className="mt-2"
                      />
                    </div>
                  </div>

                  {/* Submit Buttons */}
                  <div className="flex gap-3">
                    <Button
                      type="submit"
                      className="flex-1 bg-blue-600 hover:bg-blue-700"
                      disabled={analyzeTransaction.isPending}
                    >
                      <Send className="w-4 h-4 mr-2" />
                      Analyze Transaction
                    </Button>
                    <Button
                      type="button"
                      variant="outline"
                      onClick={generateBulkTransactions}
                      disabled={isGenerating}
                    >
                      <Zap className="w-4 h-4 mr-2" />
                      Generate 10
                    </Button>
                  </div>
                </form>
              </CardContent>
            </Card>
          </div>

          {/* Stats */}
          <div className="space-y-4">
            <Card className="bg-white shadow-sm border-0">
              <CardHeader>
                <CardTitle className="text-lg">Statistics</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <p className="text-sm text-slate-600">Transactions Generated</p>
                  <p className="text-3xl font-bold text-slate-900">{generatedCount}</p>
                </div>

                <div className="p-4 bg-blue-50 rounded-lg border border-blue-200">
                  <p className="text-sm font-semibold text-blue-900 mb-2">💡 Tips for Testing</p>
                  <ul className="text-xs text-blue-800 space-y-1">
                    <li>• High amounts trigger fraud alerts</li>
                    <li>• High device risk increases score</li>
                    <li>• Unusual locations raise suspicion</li>
                    <li>• Generate bulk transactions to see patterns</li>
                  </ul>
                </div>

                <div className="p-4 bg-amber-50 rounded-lg border border-amber-200">
                  <p className="text-sm font-semibold text-amber-900 mb-2">⚠️ Note</p>
                  <p className="text-xs text-amber-800">
                    This system uses heuristic-based fraud detection for demonstration. In production, ML models would be used.
                  </p>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}
