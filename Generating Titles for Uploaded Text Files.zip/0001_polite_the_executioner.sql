CREATE TABLE `fraudAlerts` (
	`id` int AUTO_INCREMENT NOT NULL,
	`transactionId` varchar(64) NOT NULL,
	`customerId` varchar(64) NOT NULL,
	`alertType` varchar(64) NOT NULL,
	`severity` enum('low','medium','high','critical') NOT NULL,
	`message` text NOT NULL,
	`isResolved` int NOT NULL DEFAULT 0,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`resolvedAt` timestamp,
	CONSTRAINT `fraudAlerts_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `fraudStats` (
	`id` int AUTO_INCREMENT NOT NULL,
	`date` varchar(10) NOT NULL,
	`hour` int NOT NULL,
	`totalTransactions` int NOT NULL DEFAULT 0,
	`fraudCount` int NOT NULL DEFAULT 0,
	`totalAmount` int NOT NULL DEFAULT 0,
	`fraudAmount` int NOT NULL DEFAULT 0,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `fraudStats_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `transactions` (
	`id` int AUTO_INCREMENT NOT NULL,
	`transactionId` varchar(64) NOT NULL,
	`customerId` varchar(64) NOT NULL,
	`amount` int NOT NULL,
	`location` varchar(255) NOT NULL,
	`merchant` varchar(255) NOT NULL,
	`paymentMode` varchar(64) NOT NULL,
	`isFraud` int NOT NULL DEFAULT 0,
	`fraudScore` int NOT NULL DEFAULT 0,
	`fraudProbability` int NOT NULL DEFAULT 0,
	`modelUsed` varchar(64) NOT NULL DEFAULT 'xgboost',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `transactions_id` PRIMARY KEY(`id`),
	CONSTRAINT `transactions_transactionId_unique` UNIQUE(`transactionId`)
);
