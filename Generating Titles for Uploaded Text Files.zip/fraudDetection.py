import pickle
import json
import numpy as np
from pathlib import Path
import sys

# Add models directory to path
models_dir = Path(__file__).parent / 'models'
sys.path.insert(0, str(models_dir))

class FraudDetectionEngine:
    """Real-time fraud detection engine using trained ML models"""
    
    def __init__(self, model_type='xgboost'):
        self.model_type = model_type
        self.model = None
        self.scaler = None
        self.feature_names = None
        self.threshold = 0.5
        self.load_models()
    
    def load_models(self):
        """Load pre-trained models and scaler"""
        try:
            model_path = models_dir / f'{self.model_type}_model.pkl'
            scaler_path = models_dir / 'scaler.pkl'
            metadata_path = models_dir / 'metadata.json'
            
            with open(model_path, 'rb') as f:
                self.model = pickle.load(f)
            
            with open(scaler_path, 'rb') as f:
                self.scaler = pickle.load(f)
            
            with open(metadata_path, 'r') as f:
                metadata = json.load(f)
                self.feature_names = metadata['feature_names']
                self.threshold = metadata.get('threshold', 0.5)
            
            print(f"✓ Loaded {self.model_type} model successfully")
        except Exception as e:
            print(f"✗ Error loading models: {e}")
            raise
    
    def extract_features(self, transaction):
        """Extract features from transaction data"""
        features = {
            'Amount': float(transaction.get('amount', 0)) / 100,  # Convert cents to dollars
            'Time': int(transaction.get('time', 0)),
            'Frequency': int(transaction.get('frequency', 1)),
            'Distance': float(transaction.get('distance', 0)),
            'Card_Age': float(transaction.get('card_age', 1000)),
            'Device_Risk': float(transaction.get('device_risk', 0.1)),
            'Location_Risk': float(transaction.get('location_risk', 0.1)),
            'Hour_of_Day': int(transaction.get('hour', 12)),
            'Day_of_Week': int(transaction.get('day_of_week', 3)),
            'Merchant_Risk': float(transaction.get('merchant_risk', 0.1)),
        }
        
        # Create feature vector in the correct order
        feature_vector = np.array([[features[name] for name in self.feature_names]])
        return feature_vector
    
    def predict(self, transaction):
        """Predict if transaction is fraudulent"""
        try:
            # Extract and scale features
            features = self.extract_features(transaction)
            features_scaled = self.scaler.transform(features)
            
            # Get prediction and probability
            prediction = self.model.predict(features_scaled)[0]
            probability = self.model.predict_proba(features_scaled)[0][1]
            
            # Determine fraud status
            is_fraud = 1 if probability >= self.threshold else 0
            fraud_score = int(probability * 100)
            
            return {
                'is_fraud': is_fraud,
                'probability': float(probability),
                'fraud_score': fraud_score,
                'confidence': float(max(self.model.predict_proba(features_scaled)[0])),
            }
        except Exception as e:
            print(f"✗ Error in prediction: {e}")
            return {
                'is_fraud': 0,
                'probability': 0.0,
                'fraud_score': 0,
                'confidence': 0.0,
            }

# Initialize engine
fraud_engine = None

def get_fraud_engine():
    """Get or initialize fraud detection engine"""
    global fraud_engine
    if fraud_engine is None:
        fraud_engine = FraudDetectionEngine(model_type='xgboost')
    return fraud_engine

def detect_fraud(transaction):
    """Detect fraud in a transaction"""
    engine = get_fraud_engine()
    return engine.predict(transaction)
