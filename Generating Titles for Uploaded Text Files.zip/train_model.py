#!/usr/bin/env python3
"""
Real-Time Fraud Detection System - ML Model Training Pipeline
Trains XGBoost and Random Forest models on credit card fraud dataset
"""

import numpy as np
import pandas as pd
import pickle
import json
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import (
    classification_report,
    confusion_matrix,
    roc_auc_score,
    precision_recall_curve,
    f1_score,
)
from sklearn.utils import class_weight
import xgboost as xgb
from datetime import datetime
import os

# Set random seed for reproducibility
np.random.seed(42)

def generate_synthetic_fraud_dataset(n_samples=10000):
    """
    Generate a synthetic credit card fraud dataset
    Similar to the Credit Card Fraud Detection Dataset structure
    """
    print("Generating synthetic fraud dataset...")
    
    # Generate features
    np.random.seed(42)
    
    # Normal transactions (class 0)
    n_normal = int(n_samples * 0.98)
    
    # Features for normal transactions
    normal_data = {
        'Amount': np.random.exponential(scale=100, size=n_normal),
        'Time': np.random.randint(0, 86400, n_normal),
        'Frequency': np.random.poisson(lam=2, size=n_normal),
        'Distance': np.random.exponential(scale=50, size=n_normal),
        'Card_Age': np.random.exponential(scale=1000, size=n_normal),
        'Device_Risk': np.random.uniform(0, 0.3, size=n_normal),
        'Location_Risk': np.random.uniform(0, 0.2, size=n_normal),
        'Hour_of_Day': np.random.randint(0, 24, n_normal),
        'Day_of_Week': np.random.randint(0, 7, n_normal),
        'Merchant_Risk': np.random.uniform(0, 0.25, size=n_normal),
    }
    normal_df = pd.DataFrame(normal_data)
    normal_df['Class'] = 0
    
    # Fraudulent transactions (class 1)
    n_fraud = n_samples - n_normal
    fraud_data = {
        'Amount': np.random.exponential(scale=500, size=n_fraud),  # Higher amounts
        'Time': np.random.randint(0, 86400, n_fraud),
        'Frequency': np.random.poisson(lam=5, size=n_fraud),  # Higher frequency
        'Distance': np.random.exponential(scale=200, size=n_fraud),  # Larger distances
        'Card_Age': np.random.exponential(scale=200, size=n_fraud),  # Newer cards
        'Device_Risk': np.random.uniform(0.5, 1.0, size=n_fraud),  # High device risk
        'Location_Risk': np.random.uniform(0.5, 1.0, size=n_fraud),  # High location risk
        'Hour_of_Day': np.random.choice([2, 3, 4, 23], size=n_fraud),  # Odd hours
        'Day_of_Week': np.random.choice([5, 6], size=n_fraud),  # Weekends
        'Merchant_Risk': np.random.uniform(0.6, 1.0, size=n_fraud),  # High merchant risk
    }
    fraud_df = pd.DataFrame(fraud_data)
    fraud_df['Class'] = 1
    
    # Combine datasets
    df = pd.concat([normal_df, fraud_df], ignore_index=True)
    df = df.sample(frac=1, random_state=42).reset_index(drop=True)
    
    print(f"Dataset shape: {df.shape}")
    print(f"Fraud cases: {(df['Class'] == 1).sum()} ({(df['Class'] == 1).sum() / len(df) * 100:.2f}%)")
    print(f"Normal cases: {(df['Class'] == 0).sum()} ({(df['Class'] == 0).sum() / len(df) * 100:.2f}%)")
    
    return df

def prepare_data(df):
    """Prepare and split data for training"""
    print("\nPreparing data...")
    
    X = df.drop('Class', axis=1)
    y = df['Class']
    
    # Split data
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=42, stratify=y
    )
    
    # Scale features
    scaler = StandardScaler()
    X_train_scaled = scaler.fit_transform(X_train)
    X_test_scaled = scaler.transform(X_test)
    
    print(f"Training set size: {X_train_scaled.shape}")
    print(f"Test set size: {X_test_scaled.shape}")
    
    return X_train_scaled, X_test_scaled, y_train, y_test, scaler, X.columns.tolist()

def train_xgboost_model(X_train, X_test, y_train, y_test):
    """Train XGBoost model"""
    print("\nTraining XGBoost model...")
    
    # Calculate class weights to handle imbalance
    class_weights = class_weight.compute_class_weight(
        'balanced', classes=np.unique(y_train), y=y_train
    )
    scale_pos_weight = class_weights[1] / class_weights[0]
    
    model = xgb.XGBClassifier(
        n_estimators=100,
        max_depth=6,
        learning_rate=0.1,
        subsample=0.8,
        colsample_bytree=0.8,
        scale_pos_weight=scale_pos_weight,
        random_state=42,
        eval_metric='logloss',
        tree_method='hist',
    )
    
    model.fit(X_train, y_train, verbose=False)
    
    # Evaluate
    y_pred = model.predict(X_test)
    y_pred_proba = model.predict_proba(X_test)[:, 1]
    
    print("XGBoost Model Performance:")
    print(f"ROC-AUC Score: {roc_auc_score(y_test, y_pred_proba):.4f}")
    print(f"F1 Score: {f1_score(y_test, y_pred):.4f}")
    print("\nClassification Report:")
    print(classification_report(y_test, y_pred, target_names=['Normal', 'Fraud']))
    
    return model, y_pred_proba

def train_random_forest_model(X_train, X_test, y_train, y_test):
    """Train Random Forest model"""
    print("\nTraining Random Forest model...")
    
    # Calculate class weights
    class_weights = class_weight.compute_class_weight(
        'balanced', classes=np.unique(y_train), y=y_train
    )
    
    model = RandomForestClassifier(
        n_estimators=100,
        max_depth=15,
        min_samples_split=10,
        min_samples_leaf=5,
        class_weight='balanced',
        random_state=42,
        n_jobs=-1,
    )
    
    model.fit(X_train, y_train)
    
    # Evaluate
    y_pred = model.predict(X_test)
    y_pred_proba = model.predict_proba(X_test)[:, 1]
    
    print("Random Forest Model Performance:")
    print(f"ROC-AUC Score: {roc_auc_score(y_test, y_pred_proba):.4f}")
    print(f"F1 Score: {f1_score(y_test, y_pred):.4f}")
    print("\nClassification Report:")
    print(classification_report(y_test, y_pred, target_names=['Normal', 'Fraud']))
    
    return model, y_pred_proba

def save_models(xgb_model, rf_model, scaler, feature_names):
    """Save trained models and scaler"""
    print("\nSaving models...")
    
    # Create models directory
    os.makedirs('server/models', exist_ok=True)
    
    # Save models
    with open('server/models/xgboost_model.pkl', 'wb') as f:
        pickle.dump(xgb_model, f)
    
    with open('server/models/random_forest_model.pkl', 'wb') as f:
        pickle.dump(rf_model, f)
    
    with open('server/models/scaler.pkl', 'wb') as f:
        pickle.dump(scaler, f)
    
    # Save feature names and metadata
    metadata = {
        'feature_names': feature_names,
        'n_features': len(feature_names),
        'trained_at': datetime.now().isoformat(),
        'model_type': 'xgboost',
        'threshold': 0.5,
    }
    
    with open('server/models/metadata.json', 'w') as f:
        json.dump(metadata, f, indent=2)
    
    print("✓ Models saved successfully")
    print(f"  - XGBoost model: server/models/xgboost_model.pkl")
    print(f"  - Random Forest model: server/models/random_forest_model.pkl")
    print(f"  - Scaler: server/models/scaler.pkl")
    print(f"  - Metadata: server/models/metadata.json")

def main():
    """Main training pipeline"""
    print("=" * 60)
    print("Real-Time Fraud Detection System - Model Training")
    print("=" * 60)
    
    # Generate dataset
    df = generate_synthetic_fraud_dataset(n_samples=10000)
    
    # Prepare data
    X_train, X_test, y_train, y_test, scaler, feature_names = prepare_data(df)
    
    # Train models
    xgb_model, xgb_pred_proba = train_xgboost_model(X_train, X_test, y_train, y_test)
    rf_model, rf_pred_proba = train_random_forest_model(X_train, X_test, y_train, y_test)
    
    # Save models
    save_models(xgb_model, rf_model, scaler, feature_names)
    
    print("\n" + "=" * 60)
    print("Model training completed successfully!")
    print("=" * 60)

if __name__ == '__main__':
    main()
