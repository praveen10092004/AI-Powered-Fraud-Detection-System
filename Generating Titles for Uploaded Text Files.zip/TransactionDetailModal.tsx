import { useState } from "react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { AlertTriangle, CheckCircle2, TrendingUp, DollarSign, MapPin, Smartphone, Store } from "lucide-react";

interface RiskFactor {
  name: string;
  value: number;
  threshold: number;
  contribution: number;
  triggered: boolean;
  icon: React.ReactNode;
  description: string;
}

interface TransactionDetailModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  transaction: {
    transactionId: string;
    customerId: string;
    amount: number;
    location: string;
    merchant: string;
    paymentMode: string;
    fraudScore: number;
    isFraud: number;
    frequency?: number;
    distance?: number;
    deviceRisk?: number;
    locationRisk?: number;
    merchantRisk?: number;
    hour?: number;
    dayOfWeek?: number;
    amountContribution?: number;
    frequencyContribution?: number;
    locationContribution?: number;
    deviceContribution?: number;
    merchantContribution?: number;
    createdAt?: Date;
  };
}

export function TransactionDetailModal({
  open,
  onOpenChange,
  transaction,
}: TransactionDetailModalProps) {
  const riskFactors: RiskFactor[] = [
    {
      name: "Transaction Amount",
      value: transaction.amount,
      threshold: 5000,
      contribution: transaction.amountContribution || 0,
      triggered: (transaction.amountContribution || 0) > 0,
      icon: <DollarSign className="w-5 h-5" />,
      description: `$${transaction.amount.toFixed(2)} - High amounts increase fraud risk`,
    },
    {
      name: "Transaction Frequency",
      value: transaction.frequency || 1,
      threshold: 5,
      contribution: transaction.frequencyContribution || 0,
      triggered: (transaction.frequencyContribution || 0) > 0,
      icon: <TrendingUp className="w-5 h-5" />,
      description: `${transaction.frequency || 1} transactions - Multiple rapid transactions are suspicious`,
    },
    {
      name: "Location Risk",
      value: (transaction.locationRisk || 10) / 100,
      threshold: 0.7,
      contribution: transaction.locationContribution || 0,
      triggered: (transaction.locationContribution || 0) > 0,
      icon: <MapPin className="w-5 h-5" />,
      description: `${transaction.locationRisk || 10}% risk - Unusual location detected`,
    },
    {
      name: "Device Risk",
      value: (transaction.deviceRisk || 10) / 100,
      threshold: 0.7,
      contribution: transaction.deviceContribution || 0,
      triggered: (transaction.deviceContribution || 0) > 0,
      icon: <Smartphone className="w-5 h-5" />,
      description: `${transaction.deviceRisk || 10}% risk - Suspicious device profile`,
    },
    {
      name: "Merchant Risk",
      value: (transaction.merchantRisk || 10) / 100,
      threshold: 0.7,
      contribution: transaction.merchantContribution || 0,
      triggered: (transaction.merchantContribution || 0) > 0,
      icon: <Store className="w-5 h-5" />,
      description: `${transaction.merchantRisk || 10}% risk - High-risk merchant category`,
    },
  ];

  const triggeredFactors = riskFactors.filter((f) => f.triggered);
  const totalContribution = riskFactors.reduce((sum, f) => sum + f.contribution, 0);

  const getScoreColor = (score: number) => {
    if (score >= 70) return "text-red-600";
    if (score >= 50) return "text-orange-600";
    if (score >= 30) return "text-yellow-600";
    return "text-green-600";
  };

  const getScoreBgColor = (score: number) => {
    if (score >= 70) return "bg-red-50";
    if (score >= 50) return "bg-orange-50";
    if (score >= 30) return "bg-yellow-50";
    return "bg-green-50";
  };

  const formatDate = (date: Date | undefined) => {
    if (!date) return "N/A";
    return new Date(date).toLocaleString();
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <span>Transaction Details</span>
            <Badge variant="outline" className="ml-auto">
              {transaction.transactionId}
            </Badge>
          </DialogTitle>
          <DialogDescription>
            Detailed fraud score breakdown and risk factor analysis
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-6">
          {/* Transaction Summary */}
          <Card className="border-0 bg-slate-50">
            <CardHeader className="pb-3">
              <CardTitle className="text-base">Transaction Summary</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <p className="text-sm text-slate-600">Customer ID</p>
                  <p className="font-mono text-sm font-semibold">{transaction.customerId}</p>
                </div>
                <div>
                  <p className="text-sm text-slate-600">Amount</p>
                  <p className="text-lg font-bold">${transaction.amount.toFixed(2)}</p>
                </div>
                <div>
                  <p className="text-sm text-slate-600">Merchant</p>
                  <p className="font-semibold">{transaction.merchant}</p>
                </div>
                <div>
                  <p className="text-sm text-slate-600">Location</p>
                  <p className="font-semibold">{transaction.location}</p>
                </div>
                <div>
                  <p className="text-sm text-slate-600">Payment Mode</p>
                  <p className="font-semibold">{transaction.paymentMode}</p>
                </div>
                <div>
                  <p className="text-sm text-slate-600">Timestamp</p>
                  <p className="text-sm">{formatDate(transaction.createdAt)}</p>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Fraud Score Overview */}
          <Card className={`border-0 ${getScoreBgColor(transaction.fraudScore)}`}>
            <CardHeader className="pb-3">
              <CardTitle className="text-base flex items-center justify-between">
                <span>Fraud Score</span>
                {transaction.isFraud ? (
                  <AlertTriangle className="w-5 h-5 text-red-600" />
                ) : (
                  <CheckCircle2 className="w-5 h-5 text-green-600" />
                )}
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-end gap-4">
                <div>
                  <p className={`text-5xl font-bold ${getScoreColor(transaction.fraudScore)}`}>
                    {transaction.fraudScore}
                  </p>
                  <p className="text-sm text-slate-600 mt-1">out of 100</p>
                </div>
                <div className="flex-1">
                  <Progress
                    value={transaction.fraudScore}
                    className="h-3"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4 pt-2 border-t border-slate-200">
                <div>
                  <p className="text-sm text-slate-600">Status</p>
                  <Badge
                    className={
                      transaction.isFraud
                        ? "bg-red-100 text-red-800 mt-1"
                        : "bg-green-100 text-green-800 mt-1"
                    }
                  >
                    {transaction.isFraud ? "🚨 FRAUD" : "✓ NORMAL"}
                  </Badge>
                </div>
                <div>
                  <p className="text-sm text-slate-600">Risk Level</p>
                  <Badge
                    className={`mt-1 ${
                      transaction.fraudScore >= 70
                        ? "bg-red-100 text-red-800"
                        : transaction.fraudScore >= 50
                          ? "bg-orange-100 text-orange-800"
                          : transaction.fraudScore >= 30
                            ? "bg-yellow-100 text-yellow-800"
                            : "bg-green-100 text-green-800"
                    }`}
                  >
                    {transaction.fraudScore >= 70
                      ? "Critical"
                      : transaction.fraudScore >= 50
                        ? "High"
                        : transaction.fraudScore >= 30
                          ? "Medium"
                          : "Low"}
                  </Badge>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Risk Factors Breakdown */}
          <Card className="border-0">
            <CardHeader className="pb-3">
              <CardTitle className="text-base">
                Risk Factors ({triggeredFactors.length} triggered)
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              {riskFactors.map((factor, index) => (
                <div
                  key={index}
                  className={`p-4 rounded-lg border-2 transition ${
                    factor.triggered
                      ? "border-red-200 bg-red-50"
                      : "border-green-200 bg-green-50"
                  }`}
                >
                  <div className="flex items-start justify-between mb-3">
                    <div className="flex items-center gap-3">
                      <div
                        className={`p-2 rounded-lg ${
                          factor.triggered ? "bg-red-100 text-red-600" : "bg-green-100 text-green-600"
                        }`}
                      >
                        {factor.icon}
                      </div>
                      <div>
                        <p className="font-semibold text-slate-900">{factor.name}</p>
                        <p className="text-sm text-slate-600">{factor.description}</p>
                      </div>
                    </div>
                    <div className="text-right">
                      <Badge
                        className={
                          factor.triggered
                            ? "bg-red-100 text-red-800"
                            : "bg-green-100 text-green-800"
                        }
                      >
                        {factor.triggered ? "TRIGGERED" : "OK"}
                      </Badge>
                    </div>
                  </div>

                  {/* Factor Details */}
                  <div className="grid grid-cols-3 gap-3 text-sm">
                    <div>
                      <p className="text-slate-600">Current Value</p>
                      <p className="font-mono font-semibold">
                        {typeof factor.value === "number"
                          ? factor.value > 1
                            ? factor.value.toFixed(2)
                            : (factor.value * 100).toFixed(0) + "%"
                          : factor.value}
                      </p>
                    </div>
                    <div>
                      <p className="text-slate-600">Threshold</p>
                      <p className="font-mono font-semibold">
                        {typeof factor.threshold === "number"
                          ? factor.threshold > 1
                            ? factor.threshold.toFixed(2)
                            : (factor.threshold * 100).toFixed(0) + "%"
                          : factor.threshold}
                      </p>
                    </div>
                    <div>
                      <p className="text-slate-600">Contribution</p>
                      <p
                        className={`font-mono font-semibold ${
                          factor.triggered ? "text-red-600" : "text-green-600"
                        }`}
                      >
                        {factor.triggered ? "+" : ""}
                        {factor.contribution} pts
                      </p>
                    </div>
                  </div>

                  {/* Visual Indicator */}
                  {factor.triggered && (
                    <div className="mt-3 pt-3 border-t border-red-200">
                      <div className="flex items-center gap-2">
                        <div className="flex-1 bg-red-200 rounded-full h-2">
                          <div
                            className="bg-red-600 h-2 rounded-full"
                            style={{
                              width: `${Math.min(
                                ((factor.value / factor.threshold) * 100),
                                100
                              )}%`,
                            }}
                          />
                        </div>
                        <span className="text-xs font-semibold text-red-600">
                          {((factor.value / factor.threshold) * 100).toFixed(0)}%
                        </span>
                      </div>
                    </div>
                  )}
                </div>
              ))}
            </CardContent>
          </Card>

          {/* Score Calculation Summary */}
          <Card className="border-0 bg-slate-50">
            <CardHeader className="pb-3">
              <CardTitle className="text-base">Score Calculation</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2 text-sm">
                {riskFactors.map((factor, index) => (
                  factor.contribution > 0 && (
                    <div key={index} className="flex justify-between items-center">
                      <span className="text-slate-600">{factor.name}</span>
                      <span className="font-mono font-semibold text-red-600">
                        +{factor.contribution}
                      </span>
                    </div>
                  )
                ))}
                <div className="border-t border-slate-300 pt-2 mt-2 flex justify-between items-center font-semibold">
                  <span>Total Score</span>
                  <span className={`font-mono ${getScoreColor(transaction.fraudScore)}`}>
                    {transaction.fraudScore}
                  </span>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Recommendation */}
          <Card
            className={`border-0 ${
              transaction.isFraud
                ? "bg-red-50 border-red-200"
                : "bg-green-50 border-green-200"
            }`}
          >
            <CardHeader className="pb-3">
              <CardTitle className="text-base">Recommendation</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-slate-700">
                {transaction.isFraud
                  ? "⚠️ This transaction has been flagged as potentially fraudulent. Consider contacting the customer to verify the transaction details before processing."
                  : "✓ This transaction appears to be legitimate based on the risk factor analysis. No action required."}
              </p>
            </CardContent>
          </Card>
        </div>
      </DialogContent>
    </Dialog>
  );
}
