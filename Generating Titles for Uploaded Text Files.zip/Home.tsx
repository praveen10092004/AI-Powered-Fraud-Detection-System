import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { useLocation } from "wouter";
import {
  BarChart3,
  Zap,
  Shield,
  TrendingUp,
  AlertTriangle,
  Clock,
  Database,
  Gauge,
} from "lucide-react";

export default function Home() {
  const [, setLocation] = useLocation();

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900">
      {/* Navigation */}
      <nav className="bg-slate-950 border-b border-slate-700 sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-6 py-4 flex justify-between items-center">
          <div className="flex items-center gap-3">
            <Shield className="w-8 h-8 text-blue-500" />
            <h1 className="text-2xl font-bold text-white">Fraud Detection</h1>
          </div>
          <div className="flex gap-3">
            <Button variant="ghost" onClick={() => setLocation("/dashboard")} className="text-slate-300 hover:text-white">
              Dashboard
            </Button>
            <Button variant="ghost" onClick={() => setLocation("/generator")} className="text-slate-300 hover:text-white">
              Generator
            </Button>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <div className="max-w-7xl mx-auto px-6 py-20">
        <div className="text-center mb-16">
          <h2 className="text-5xl md:text-6xl font-bold text-white mb-6">
            Real-Time Fraud Detection System
          </h2>
          <p className="text-xl text-slate-300 mb-8 max-w-2xl mx-auto">
            Advanced machine learning-powered fraud detection platform that analyzes transactions in real-time to protect against fraudulent activities.
          </p>
          <div className="flex gap-4 justify-center">
            <Button
              size="lg"
              className="bg-blue-600 hover:bg-blue-700 text-white"
              onClick={() => setLocation("/dashboard")}
            >
              <BarChart3 className="w-5 h-5 mr-2" />
              View Dashboard
            </Button>
            <Button
              size="lg"
              variant="outline"
              className="border-slate-600 text-white hover:bg-slate-800"
              onClick={() => setLocation("/generator")}
            >
              <Zap className="w-5 h-5 mr-2" />
              Generate Transactions
            </Button>
          </div>
        </div>

        {/* Features Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-16">
          {/* Feature 1 */}
          <Card className="bg-slate-800 border-slate-700 hover:border-blue-500 transition">
            <CardHeader>
              <Gauge className="w-8 h-8 text-blue-500 mb-2" />
              <CardTitle className="text-white">Real-Time Analysis</CardTitle>
              <CardDescription className="text-slate-400">
                Analyze transactions instantly as they occur
              </CardDescription>
            </CardHeader>
            <CardContent className="text-slate-300">
              Process thousands of transactions per second with sub-millisecond latency.
            </CardContent>
          </Card>

          {/* Feature 2 */}
          <Card className="bg-slate-800 border-slate-700 hover:border-blue-500 transition">
            <CardHeader>
              <TrendingUp className="w-8 h-8 text-green-500 mb-2" />
              <CardTitle className="text-white">ML-Powered Detection</CardTitle>
              <CardDescription className="text-slate-400">
                Advanced machine learning models
              </CardDescription>
            </CardHeader>
            <CardContent className="text-slate-300">
              XGBoost and Random Forest models trained on millions of transactions.
            </CardContent>
          </Card>

          {/* Feature 3 */}
          <Card className="bg-slate-800 border-slate-700 hover:border-blue-500 transition">
            <CardHeader>
              <AlertTriangle className="w-8 h-8 text-orange-500 mb-2" />
              <CardTitle className="text-white">Smart Alerts</CardTitle>
              <CardDescription className="text-slate-400">
                Intelligent alert system
              </CardDescription>
            </CardHeader>
            <CardContent className="text-slate-300">
              Severity-based alerts with detailed fraud indicators and recommendations.
            </CardContent>
          </Card>

          {/* Feature 4 */}
          <Card className="bg-slate-800 border-slate-700 hover:border-blue-500 transition">
            <CardHeader>
              <Database className="w-8 h-8 text-purple-500 mb-2" />
              <CardTitle className="text-white">Data Storage</CardTitle>
              <CardDescription className="text-slate-400">
                Persistent transaction history
              </CardDescription>
            </CardHeader>
            <CardContent className="text-slate-300">
              Store and analyze transaction patterns over time with MySQL database.
            </CardContent>
          </Card>

          {/* Feature 5 */}
          <Card className="bg-slate-800 border-slate-700 hover:border-blue-500 transition">
            <CardHeader>
              <Clock className="w-8 h-8 text-cyan-500 mb-2" />
              <CardTitle className="text-white">Hourly Trends</CardTitle>
              <CardDescription className="text-slate-400">
                Pattern analysis
              </CardDescription>
            </CardHeader>
            <CardContent className="text-slate-300">
              Identify fraud patterns across different times and days.
            </CardContent>
          </Card>

          {/* Feature 6 */}
          <Card className="bg-slate-800 border-slate-700 hover:border-blue-500 transition">
            <CardHeader>
              <Shield className="w-8 h-8 text-red-500 mb-2" />
              <CardTitle className="text-white">Risk Scoring</CardTitle>
              <CardDescription className="text-slate-400">
                Comprehensive risk assessment
              </CardDescription>
            </CardHeader>
            <CardContent className="text-slate-300">
              Multi-factor fraud scoring based on transaction characteristics.
            </CardContent>
          </Card>
        </div>

        {/* System Architecture */}
        <div className="bg-slate-800 border border-slate-700 rounded-lg p-8 mb-16">
          <h3 className="text-2xl font-bold text-white mb-6">System Architecture</h3>
          <div className="grid grid-cols-1 md:grid-cols-5 gap-4 text-center">
            <div className="p-4 bg-slate-700 rounded">
              <p className="text-slate-300 font-semibold">Transaction</p>
              <p className="text-xs text-slate-400 mt-2">Generator</p>
            </div>
            <div className="flex items-center justify-center text-slate-500">→</div>
            <div className="p-4 bg-slate-700 rounded">
              <p className="text-slate-300 font-semibold">API</p>
              <p className="text-xs text-slate-400 mt-2">Analysis</p>
            </div>
            <div className="flex items-center justify-center text-slate-500">→</div>
            <div className="p-4 bg-slate-700 rounded">
              <p className="text-slate-300 font-semibold">Database</p>
              <p className="text-xs text-slate-400 mt-2">Storage</p>
            </div>
          </div>
          <div className="flex items-center justify-center text-slate-500 mt-4">↓</div>
          <div className="text-center mt-4 p-4 bg-slate-700 rounded">
            <p className="text-slate-300 font-semibold">Real-Time Dashboard</p>
            <p className="text-xs text-slate-400 mt-2">Monitoring & Analytics</p>
          </div>
        </div>

        {/* Technology Stack */}
        <div className="bg-slate-800 border border-slate-700 rounded-lg p-8">
          <h3 className="text-2xl font-bold text-white mb-6">Technology Stack</h3>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {[
              { name: "Python", category: "ML Training" },
              { name: "XGBoost", category: "Model" },
              { name: "Random Forest", category: "Model" },
              { name: "React", category: "Frontend" },
              { name: "TypeScript", category: "Language" },
              { name: "tRPC", category: "API" },
              { name: "MySQL", category: "Database" },
              { name: "Recharts", category: "Visualization" },
            ].map((tech) => (
              <div key={tech.name} className="p-4 bg-slate-700 rounded text-center">
                <p className="text-white font-semibold">{tech.name}</p>
                <p className="text-xs text-slate-400 mt-1">{tech.category}</p>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Footer */}
      <div className="border-t border-slate-700 mt-20 py-8">
        <div className="max-w-7xl mx-auto px-6 text-center text-slate-400">
          <p>Real-Time Fraud Detection System © 2026</p>
          <p className="text-sm mt-2">Built with advanced ML and real-time data processing</p>
        </div>
      </div>
    </div>
  );
}
