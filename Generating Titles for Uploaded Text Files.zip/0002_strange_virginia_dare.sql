ALTER TABLE `transactions` ADD `frequency` int DEFAULT 1 NOT NULL;--> statement-breakpoint
ALTER TABLE `transactions` ADD `distance` int DEFAULT 0 NOT NULL;--> statement-breakpoint
ALTER TABLE `transactions` ADD `deviceRisk` int DEFAULT 10 NOT NULL;--> statement-breakpoint
ALTER TABLE `transactions` ADD `locationRisk` int DEFAULT 10 NOT NULL;--> statement-breakpoint
ALTER TABLE `transactions` ADD `merchantRisk` int DEFAULT 10 NOT NULL;--> statement-breakpoint
ALTER TABLE `transactions` ADD `hour` int DEFAULT 12 NOT NULL;--> statement-breakpoint
ALTER TABLE `transactions` ADD `dayOfWeek` int DEFAULT 3 NOT NULL;--> statement-breakpoint
ALTER TABLE `transactions` ADD `amountContribution` int DEFAULT 0 NOT NULL;--> statement-breakpoint
ALTER TABLE `transactions` ADD `frequencyContribution` int DEFAULT 0 NOT NULL;--> statement-breakpoint
ALTER TABLE `transactions` ADD `locationContribution` int DEFAULT 0 NOT NULL;--> statement-breakpoint
ALTER TABLE `transactions` ADD `deviceContribution` int DEFAULT 0 NOT NULL;--> statement-breakpoint
ALTER TABLE `transactions` ADD `merchantContribution` int DEFAULT 0 NOT NULL;