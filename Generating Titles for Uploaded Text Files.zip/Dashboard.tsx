import { useEffect, useState } from "react";
import {
  AreaChart,
  Area,
  BarChart,
  Bar,
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
} from "recharts";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { AlertTriangle, TrendingUp, AlertCircle, CheckCircle2, Clock } from "lucide-react";
import { trpc } from "@/lib/trpc";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { TransactionDetailModal } from "@/components/TransactionDetailModal";

interface Transaction {
  id: number;
  transactionId: string;
  customerId: string;
  amount: number;
  location: string;
  merchant: string;
  paymentMode: string;
  isFraud: number;
  fraudScore: number;
  fraudProbability: number;
  modelUsed: string;
  createdAt: Date;
}

interface FraudAlert {
  id: number;
  transactionId: string;
  customerId: string;
  alertType: string;
  severity: "low" | "medium" | "high" | "critical";
  message: string;
  isResolved: number;
  createdAt: Date;
}

interface FraudStats {
  totalTransactions: number;
  fraudCount: number;
  totalAmount: number;
  fraudAmount: number;
  fraudRate: number;
}

interface FraudTrend {
  hour: number;
  date: string;
  totalCount: number;
  fraudCount: number;
  totalAmount: number;
  fraudAmount: number;
  fraudRate: number;
}

const SEVERITY_COLORS = {
  low: "#22c55e",
  medium: "#eab308",
  high: "#f97316",
  critical: "#ef4444",
};

export default function Dashboard() {
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [alerts, setAlerts] = useState<FraudAlert[]>([]);
  const [stats, setStats] = useState<FraudStats | null>(null);
  const [trends, setTrends] = useState<FraudTrend[]>([]);
  const [autoRefresh, setAutoRefresh] = useState(true);
  const [selectedTransaction, setSelectedTransaction] = useState<Transaction | null>(null);
  const [modalOpen, setModalOpen] = useState(false);

  const getRecentTransactions = trpc.fraud.getRecentTransactions.useQuery({ limit: 50 });
  const getFraudAlerts = trpc.fraud.getFraudAlerts.useQuery({ limit: 20, unresolved: true });
  const getFraudStats = trpc.fraud.getFraudStats.useQuery({ hoursBack: 24 });
  const getFraudTrends = trpc.fraud.getFraudTrends.useQuery({ hoursBack: 24 });
  const resolveAlert = trpc.fraud.resolveAlert.useMutation();

  // Auto-refresh data
  useEffect(() => {
    if (!autoRefresh) return;

    const interval = setInterval(() => {
      getRecentTransactions.refetch();
      getFraudAlerts.refetch();
      getFraudStats.refetch();
      getFraudTrends.refetch();
    }, 5000);

    return () => clearInterval(interval);
  }, [autoRefresh, getRecentTransactions, getFraudAlerts, getFraudStats, getFraudTrends]);

  // Update state when data loads
  useEffect(() => {
    if (getRecentTransactions.data) {
      setTransactions(getRecentTransactions.data);
    }
  }, [getRecentTransactions.data]);

  useEffect(() => {
    if (getFraudAlerts.data) {
      setAlerts(getFraudAlerts.data);
    }
  }, [getFraudAlerts.data]);

  useEffect(() => {
    if (getFraudStats.data) {
      setStats(getFraudStats.data);
    }
  }, [getFraudStats.data]);

  useEffect(() => {
    if (getFraudTrends.data) {
      setTrends(getFraudTrends.data);
    }
  }, [getFraudTrends.data]);

  const handleResolveAlert = async (alertId: number) => {
    try {
      await resolveAlert.mutateAsync({ alertId });
      setAlerts(alerts.filter((a) => a.id !== alertId));
    } catch (error) {
      console.error("Error resolving alert:", error);
    }
  };

  const fraudRateData = [
    { name: "Normal", value: stats ? stats.totalTransactions - stats.fraudCount : 0, fill: "#22c55e" },
    { name: "Fraud", value: stats ? stats.fraudCount : 0, fill: "#ef4444" },
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 p-6">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <div className="flex justify-between items-center mb-4">
            <div>
              <h1 className="text-4xl font-bold text-slate-900 mb-2">Fraud Detection System</h1>
              <p className="text-slate-600">Real-time monitoring and analysis dashboard</p>
            </div>
            <div className="flex gap-2">
              <Button
                variant={autoRefresh ? "default" : "outline"}
                onClick={() => setAutoRefresh(!autoRefresh)}
              >
                {autoRefresh ? "Auto-Refresh: ON" : "Auto-Refresh: OFF"}
              </Button>
              <Button variant="outline" onClick={() => getRecentTransactions.refetch()}>
                Refresh Now
              </Button>
            </div>
          </div>
        </div>

        {/* KPI Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
          <Card className="bg-white shadow-sm border-0">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium text-slate-600">Total Transactions</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-slate-900">
                {stats?.totalTransactions || 0}
              </div>
              <p className="text-xs text-slate-500 mt-2">Last 24 hours</p>
            </CardContent>
          </Card>

          <Card className="bg-white shadow-sm border-0">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium text-slate-600">Fraudulent Transactions</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-red-600">{stats?.fraudCount || 0}</div>
              <p className="text-xs text-slate-500 mt-2">
                {stats ? `${stats.fraudRate.toFixed(2)}% fraud rate` : "0% fraud rate"}
              </p>
            </CardContent>
          </Card>

          <Card className="bg-white shadow-sm border-0">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium text-slate-600">Total Amount</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-slate-900">
                ${(stats?.totalAmount || 0).toFixed(2)}
              </div>
              <p className="text-xs text-slate-500 mt-2">Processed volume</p>
            </CardContent>
          </Card>

          <Card className="bg-white shadow-sm border-0">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium text-slate-600">Active Alerts</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-orange-600">{alerts.length}</div>
              <p className="text-xs text-slate-500 mt-2">Unresolved alerts</p>
            </CardContent>
          </Card>
        </div>

        {/* Critical Alerts Section */}
        {alerts.length > 0 && (
          <div className="mb-8">
            <Alert className="border-red-200 bg-red-50">
              <AlertTriangle className="h-4 w-4 text-red-600" />
              <AlertTitle className="text-red-900">Active Fraud Alerts</AlertTitle>
              <AlertDescription className="text-red-800">
                {alerts.length} unresolved fraud alerts detected. Review and take action immediately.
              </AlertDescription>
            </Alert>
          </div>
        )}

        {/* Charts Section */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
          {/* Fraud Trends */}
          <Card className="bg-white shadow-sm border-0">
            <CardHeader>
              <CardTitle>Fraud Trends (24h)</CardTitle>
              <CardDescription>Hourly fraud detection patterns</CardDescription>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                <AreaChart data={trends}>
                  <defs>
                    <linearGradient id="colorFraud" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#ef4444" stopOpacity={0.8} />
                      <stop offset="95%" stopColor="#ef4444" stopOpacity={0} />
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
                  <XAxis dataKey="hour" stroke="#94a3b8" />
                  <YAxis stroke="#94a3b8" />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: "#1e293b",
                      border: "1px solid #475569",
                      borderRadius: "8px",
                    }}
                    labelStyle={{ color: "#f1f5f9" }}
                  />
                  <Area
                    type="monotone"
                    dataKey="fraudCount"
                    stroke="#ef4444"
                    fillOpacity={1}
                    fill="url(#colorFraud)"
                  />
                </AreaChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>

          {/* Transaction Distribution */}
          <Card className="bg-white shadow-sm border-0">
            <CardHeader>
              <CardTitle>Transaction Distribution</CardTitle>
              <CardDescription>Normal vs Fraudulent transactions</CardDescription>
            </CardHeader>
            <CardContent className="flex items-center justify-center">
              <ResponsiveContainer width="100%" height={300}>
                <PieChart>
                  <Pie
                    data={fraudRateData}
                    cx="50%"
                    cy="50%"
                    labelLine={false}
                    label={({ name, value, percent }) =>
                      `${name}: ${value} (${(percent * 100).toFixed(0)}%)`
                    }
                    outerRadius={100}
                    fill="#8884d8"
                    dataKey="value"
                  >
                    {fraudRateData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.fill} />
                    ))}
                  </Pie>
                  <Tooltip />
                </PieChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </div>

        {/* Detailed Tabs */}
        <Tabs defaultValue="alerts" className="bg-white rounded-lg shadow-sm border-0">
          <TabsList className="border-b border-slate-200 rounded-none">
            <TabsTrigger value="alerts">Recent Alerts ({alerts.length})</TabsTrigger>
            <TabsTrigger value="transactions">Recent Transactions ({transactions.length})</TabsTrigger>
          </TabsList>

          {/* Alerts Tab */}
          <TabsContent value="alerts" className="p-6">
            {alerts.length === 0 ? (
              <div className="text-center py-12">
                <CheckCircle2 className="h-12 w-12 text-green-500 mx-auto mb-4" />
                <p className="text-slate-600">No active alerts. System is operating normally.</p>
              </div>
            ) : (
              <div className="space-y-4">
                {alerts.map((alert) => (
                  <div
                    key={alert.id}
                    className="flex items-start justify-between p-4 border border-slate-200 rounded-lg hover:bg-slate-50 transition"
                  >
                    <div className="flex-1">
                      <div className="flex items-center gap-3 mb-2">
                        <Badge
                          style={{
                            backgroundColor: SEVERITY_COLORS[alert.severity],
                            color: "white",
                          }}
                        >
                          {alert.severity.toUpperCase()}
                        </Badge>
                        <span className="font-mono text-sm text-slate-600">{alert.transactionId}</span>
                      </div>
                      <p className="text-slate-900 font-medium">{alert.message}</p>
                      <p className="text-xs text-slate-500 mt-1">
                        Type: {alert.alertType} | Customer: {alert.customerId}
                      </p>
                    </div>
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => handleResolveAlert(alert.id)}
                      disabled={resolveAlert.isPending}
                    >
                      Resolve
                    </Button>
                  </div>
                ))}
              </div>
            )}
          </TabsContent>

          {/* Transactions Tab */}
          <TabsContent value="transactions" className="p-6">
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b border-slate-200">
                    <th className="text-left py-3 px-4 font-semibold text-slate-700">Transaction ID</th>
                    <th className="text-left py-3 px-4 font-semibold text-slate-700">Customer</th>
                    <th className="text-left py-3 px-4 font-semibold text-slate-700">Amount</th>
                    <th className="text-left py-3 px-4 font-semibold text-slate-700">Merchant</th>
                    <th className="text-left py-3 px-4 font-semibold text-slate-700">Fraud Score</th>
                    <th className="text-left py-3 px-4 font-semibold text-slate-700">Status</th>
                  </tr>
                </thead>
                <tbody>
                  {transactions.slice(0, 20).map((tx) => (
                    <tr
                      key={tx.id}
                      className="border-b border-slate-100 hover:bg-slate-50 cursor-pointer transition"
                      onClick={() => {
                        setSelectedTransaction(tx);
                        setModalOpen(true);
                      }}
                    >
                      <td className="py-3 px-4 font-mono text-xs text-slate-600">{tx.transactionId}</td>
                      <td className="py-3 px-4 text-slate-900">{tx.customerId}</td>
                      <td className="py-3 px-4 text-slate-900">${tx.amount.toFixed(2)}</td>
                      <td className="py-3 px-4 text-slate-600">{tx.merchant}</td>
                      <td className="py-3 px-4">
                        <div className="flex items-center gap-2">
                          <div className="w-16 bg-slate-200 rounded-full h-2">
                            <div
                              className={`h-2 rounded-full ${
                                tx.fraudScore > 70
                                  ? "bg-red-500"
                                  : tx.fraudScore > 40
                                    ? "bg-yellow-500"
                                    : "bg-green-500"
                              }`}
                              style={{ width: `${tx.fraudScore}%` }}
                            />
                          </div>
                          <span className="text-xs font-semibold">{tx.fraudScore}</span>
                        </div>
                      </td>
                      <td className="py-3 px-4">
                        {tx.isFraud ? (
                          <Badge className="bg-red-100 text-red-800">Fraud</Badge>
                        ) : (
                          <Badge className="bg-green-100 text-green-800">Normal</Badge>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </TabsContent>
        </Tabs>

        {/* Transaction Detail Modal */}
        {selectedTransaction && (
          <TransactionDetailModal
            open={modalOpen}
            onOpenChange={setModalOpen}
            transaction={selectedTransaction}
          />
        )}
      </div>
    </div>
  );
}
