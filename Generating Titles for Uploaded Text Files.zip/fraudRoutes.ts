import { protectedProcedure, publicProcedure, router } from "./_core/trpc";
import { z } from "zod";
import { getDb } from "./db";
import { transactions, fraudAlerts, fraudStats } from "../drizzle/schema";
import { eq, and, gte, lte, sql } from "drizzle-orm";
import { nanoid } from "nanoid";

// Transaction schema for validation
const TransactionSchema = z.object({
  amount: z.number().positive(),
  customerId: z.string(),
  location: z.string(),
  merchant: z.string(),
  paymentMode: z.string(),
  frequency: z.number().default(1),
  distance: z.number().default(0),
  card_age: z.number().default(1000),
  device_risk: z.number().default(0.1),
  location_risk: z.number().default(0.1),
  hour: z.number().default(12),
  day_of_week: z.number().default(3),
  merchant_risk: z.number().default(0.1),
  time: z.number().default(0),
});

// Risk factor breakdown interface
interface RiskFactorBreakdown {
  amountContribution: number;
  frequencyContribution: number;
  locationContribution: number;
  deviceContribution: number;
  merchantContribution: number;
}

export const fraudRouter = router({
  // Analyze a single transaction for fraud
  analyzeTransaction: publicProcedure
    .input(TransactionSchema)
    .mutation(async ({ input }) => {
      const db = await getDb();
      if (!db) {
        throw new Error("Database not available");
      }

      const transactionId = `TXN-${nanoid(12)}`;
      const timestamp = new Date();
      const dateStr = timestamp.toISOString().split("T")[0];
      const hour = timestamp.getHours();
      const dayOfWeek = timestamp.getDay();

      try {
        // Calculate fraud score and get breakdown
        const { score: fraudScore, breakdown } = calculateFraudScoreWithBreakdown(input);
        const isFraud = fraudScore > 50 ? 1 : 0;

        // Convert risk factors from 0-1 to 0-100 scale for storage
        const deviceRiskPercent = Math.round((input.device_risk || 0.1) * 100);
        const locationRiskPercent = Math.round((input.location_risk || 0.1) * 100);
        const merchantRiskPercent = Math.round((input.merchant_risk || 0.1) * 100);

        // Insert transaction with full risk factor details
        await db.insert(transactions).values({
          transactionId,
          customerId: input.customerId,
          amount: Math.round(input.amount * 100), // Convert to cents
          location: input.location,
          merchant: input.merchant,
          paymentMode: input.paymentMode,
          isFraud,
          fraudScore,
          fraudProbability: fraudScore,
          modelUsed: "heuristic",
          frequency: input.frequency,
          distance: input.distance,
          deviceRisk: deviceRiskPercent,
          locationRisk: locationRiskPercent,
          merchantRisk: merchantRiskPercent,
          hour,
          dayOfWeek,
          amountContribution: breakdown.amountContribution,
          frequencyContribution: breakdown.frequencyContribution,
          locationContribution: breakdown.locationContribution,
          deviceContribution: breakdown.deviceContribution,
          merchantContribution: breakdown.merchantContribution,
        });

        // Generate alerts if fraud detected
        if (isFraud) {
          const alerts = generateAlerts(input, transactionId, fraudScore);
          for (const alert of alerts) {
            await db.insert(fraudAlerts).values(alert);
          }
        }

        // Update fraud stats
        await updateFraudStats(db, dateStr, hour, input.amount, isFraud);

        return {
          transactionId,
          isFraud: isFraud === 1,
          fraudScore,
          breakdown,
          timestamp,
        };
      } catch (error) {
        console.error("Error analyzing transaction:", error);
        throw error;
      }
    }),

  // Get recent transactions
  getRecentTransactions: publicProcedure
    .input(z.object({ limit: z.number().default(50) }))
    .query(async ({ input }) => {
      const db = await getDb();
      if (!db) {
        return [];
      }

      try {
        const result = await db
          .select()
          .from(transactions)
          .orderBy((t) => sql`${t.createdAt} DESC`)
          .limit(input.limit);

        return result.map((t) => ({
          ...t,
          amount: t.amount / 100, // Convert from cents
          deviceRisk: (t.deviceRisk || 10) / 100, // Convert back to 0-1 scale
          locationRisk: (t.locationRisk || 10) / 100,
          merchantRisk: (t.merchantRisk || 10) / 100,
        }));
      } catch (error) {
        console.error("Error fetching transactions:", error);
        return [];
      }
    }),

  // Get fraud statistics
  getFraudStats: publicProcedure
    .input(
      z.object({
        date: z.string().optional(),
        hoursBack: z.number().default(24),
      })
    )
    .query(async ({ input }) => {
      const db = await getDb();
      if (!db) {
        return null;
      }

      try {
        const now = new Date();
        const hoursAgo = new Date(now.getTime() - input.hoursBack * 60 * 60 * 1000);

        const stats = await db
          .select({
            totalTransactions: sql<number>`COUNT(*)`.mapWith(Number),
            fraudCount: sql<number>`SUM(CASE WHEN ${transactions.isFraud} = 1 THEN 1 ELSE 0 END)`.mapWith(
              Number
            ),
            totalAmount: sql<number>`SUM(${transactions.amount})`.mapWith(Number),
            fraudAmount: sql<number>`SUM(CASE WHEN ${transactions.isFraud} = 1 THEN ${transactions.amount} ELSE 0 END)`.mapWith(
              Number
            ),
          })
          .from(transactions)
          .where(gte(transactions.createdAt, hoursAgo));

        const result = stats[0] || {
          totalTransactions: 0,
          fraudCount: 0,
          totalAmount: 0,
          fraudAmount: 0,
        };

        return {
          ...result,
          totalAmount: (result.totalAmount || 0) / 100,
          fraudAmount: (result.fraudAmount || 0) / 100,
          fraudRate: result.totalTransactions
            ? ((result.fraudCount || 0) / result.totalTransactions) * 100
            : 0,
        };
      } catch (error) {
        console.error("Error fetching fraud stats:", error);
        return null;
      }
    }),

  // Get fraud alerts
  getFraudAlerts: publicProcedure
    .input(z.object({ limit: z.number().default(20), unresolved: z.boolean().default(true) }))
    .query(async ({ input }) => {
      const db = await getDb();
      if (!db) {
        return [];
      }

      try {
        const conditions = input.unresolved ? eq(fraudAlerts.isResolved, 0) : undefined;
        
        const result = await db
          .select()
          .from(fraudAlerts)
          .where(conditions)
          .orderBy((a) => sql`${a.createdAt} DESC`)
          .limit(input.limit);

        return result;
      } catch (error) {
        console.error("Error fetching alerts:", error);
        return [];
      }
    }),

  // Resolve a fraud alert
  resolveAlert: publicProcedure
    .input(z.object({ alertId: z.number() }))
    .mutation(async ({ input }) => {
      const db = await getDb();
      if (!db) {
        throw new Error("Database not available");
      }

      try {
        await db
          .update(fraudAlerts)
          .set({ isResolved: 1, resolvedAt: new Date() })
          .where(eq(fraudAlerts.id, input.alertId));

        return { success: true };
      } catch (error) {
        console.error("Error resolving alert:", error);
        throw error;
      }
    }),

  // Get hourly fraud trends
  getFraudTrends: publicProcedure
    .input(z.object({ hoursBack: z.number().default(24) }))
    .query(async ({ input }) => {
      const db = await getDb();
      if (!db) {
        return [];
      }

      try {
        const now = new Date();
        const hoursAgo = new Date(now.getTime() - input.hoursBack * 60 * 60 * 1000);

        // Simplified query without GROUP BY to avoid MySQL strict mode issues
        const allTransactions = await db
          .select()
          .from(transactions)
          .where(gte(transactions.createdAt, hoursAgo));

        // Group in application layer
        const trendMap = new Map<string, any>();

        for (const tx of allTransactions) {
          const hour = new Date(tx.createdAt).getHours();
          const date = new Date(tx.createdAt).toISOString().split("T")[0];
          const key = `${date}-${hour}`;

          if (!trendMap.has(key)) {
            trendMap.set(key, {
              hour,
              date,
              totalCount: 0,
              fraudCount: 0,
              totalAmount: 0,
              fraudAmount: 0,
            });
          }

          const trend = trendMap.get(key);
          trend.totalCount += 1;
          trend.totalAmount += tx.amount;

          if (tx.isFraud) {
            trend.fraudCount += 1;
            trend.fraudAmount += tx.amount;
          }
        }

        const trends = Array.from(trendMap.values())
          .sort((a, b) => {
            const dateCompare = b.date.localeCompare(a.date);
            if (dateCompare !== 0) return dateCompare;
            return b.hour - a.hour;
          })
          .map((t) => ({
            ...t,
            totalAmount: (t.totalAmount || 0) / 100,
            fraudAmount: (t.fraudAmount || 0) / 100,
            fraudRate: t.totalCount ? ((t.fraudCount || 0) / t.totalCount) * 100 : 0,
          }));

        return trends;
      } catch (error) {
        console.error("Error fetching fraud trends:", error);
        return [];
      }
    }),
});

// Helper functions

function calculateFraudScoreWithBreakdown(
  transaction: z.infer<typeof TransactionSchema>
): { score: number; breakdown: RiskFactorBreakdown } {
  const breakdown: RiskFactorBreakdown = {
    amountContribution: 0,
    frequencyContribution: 0,
    locationContribution: 0,
    deviceContribution: 0,
    merchantContribution: 0,
  };

  // High amount risk
  if (transaction.amount > 5000) breakdown.amountContribution = 30;
  else if (transaction.amount > 1000) breakdown.amountContribution = 15;

  // High frequency risk
  if (transaction.frequency > 5) breakdown.frequencyContribution = 20;

  // Unusual location
  if (transaction.location_risk > 0.7) breakdown.locationContribution = 25;

  // High device risk
  if (transaction.device_risk > 0.7) breakdown.deviceContribution = 20;

  // High merchant risk
  if (transaction.merchant_risk > 0.7) breakdown.merchantContribution = 15;

  const score = Math.min(
    Object.values(breakdown).reduce((a, b) => a + b, 0),
    100
  );

  return { score, breakdown };
}

function calculateFraudScore(transaction: z.infer<typeof TransactionSchema>): number {
  const { score } = calculateFraudScoreWithBreakdown(transaction);
  return score;
}

function generateAlerts(
  transaction: z.infer<typeof TransactionSchema>,
  transactionId: string,
  fraudScore: number
): Array<{
  transactionId: string;
  customerId: string;
  alertType: string;
  severity: "low" | "medium" | "high" | "critical";
  message: string;
}> {
  const alerts: Array<{
    transactionId: string;
    customerId: string;
    alertType: string;
    severity: "low" | "medium" | "high" | "critical";
    message: string;
  }> = [];

  if (transaction.amount > 5000) {
    const severity: "low" | "medium" | "high" | "critical" = transaction.amount > 10000 ? "critical" : "high";
    alerts.push({
      transactionId,
      customerId: transaction.customerId,
      alertType: "high_amount",
      severity,
      message: `High transaction amount: $${transaction.amount.toFixed(2)}`,
    });
  }

  if (transaction.location_risk > 0.7) {
    alerts.push({
      transactionId,
      customerId: transaction.customerId,
      alertType: "unusual_location",
      severity: "high",
      message: `Unusual location detected: ${transaction.location}`,
    });
  }

  if (transaction.frequency > 5) {
    alerts.push({
      transactionId,
      customerId: transaction.customerId,
      alertType: "high_frequency",
      severity: "medium",
      message: `High transaction frequency: ${transaction.frequency} transactions`,
    });
  }

  if (transaction.device_risk > 0.7) {
    alerts.push({
      transactionId,
      customerId: transaction.customerId,
      alertType: "suspicious_device",
      severity: "high",
      message: "Transaction from suspicious device",
    });
  }

  return alerts;
}

async function updateFraudStats(
  db: any,
  dateStr: string,
  hour: number,
  amount: number,
  isFraud: number
) {
  try {
    const existing = await db
      .select()
      .from(fraudStats)
      .where(and(eq(fraudStats.date, dateStr), eq(fraudStats.hour, hour)))
      .limit(1);

    if (existing.length > 0) {
      await db
        .update(fraudStats)
        .set({
          totalTransactions: sql`${fraudStats.totalTransactions} + 1`,
          fraudCount: isFraud ? sql`${fraudStats.fraudCount} + 1` : fraudStats.fraudCount,
          totalAmount: sql`${fraudStats.totalAmount} + ${Math.round(amount * 100)}`,
          fraudAmount: isFraud
            ? sql`${fraudStats.fraudAmount} + ${Math.round(amount * 100)}`
            : fraudStats.fraudAmount,
        })
        .where(
          and(eq(fraudStats.date, dateStr), eq(fraudStats.hour, hour))
        );
    } else {
      await db.insert(fraudStats).values({
        date: dateStr,
        hour,
        totalTransactions: 1,
        fraudCount: isFraud,
        totalAmount: Math.round(amount * 100),
        fraudAmount: isFraud ? Math.round(amount * 100) : 0,
      });
    }
  } catch (error) {
    console.error("Error updating fraud stats:", error);
  }
}
